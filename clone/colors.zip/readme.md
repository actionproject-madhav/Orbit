### Sketch

- Use [Sketch Palettes](https://github.com/andrewfiorillo/sketch-palettes) to import `sketch palette.sketchpalette`.

### Adobe

- Import `adobe swatch.aco` via Adobe's Swatches panel.

### Figma

- In Figma, go to `Resources → Plugins → Palette Importer` (plugin required).
- Choose `Load File` and select `figma-colors.json` to import the palette.
